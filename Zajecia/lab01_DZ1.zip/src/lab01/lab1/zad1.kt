package lab01.lab1


class zad1 {
    fun hw() {
        println("Witaj obiektowy świecie")
    }
}