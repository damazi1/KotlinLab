package lab02

interface Spaliny {
    fun tank(ilosc: Int, rodzaj: RodzajPaliwa): Boolean
}